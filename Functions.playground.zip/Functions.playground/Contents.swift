import UIKit

var greeting = "Hello, playground"

func displayPI() {
    print("3.14")
}


func triple(value: Int){
    let result = value * 3
    print("Result = \(result)")
}
triple(value: 5)


func muptiply(firstNumber: Int, secondNumber: Int){
    let rsult = firstNumber * secondNumber
    print("Result = \(rsult)")
}
muptiply(firstNumber: 10, secondNumber: 4)


func multiply(firsNumber: Int, seconNumber: Int) -> Int {  //Result is also in Int
    let reesult = firsNumber * seconNumber
    return reesult
}
multiply(firsNumber: 15, seconNumber: 4)

var resultValue = multiply(firsNumber: 25, seconNumber: 5)
print("Result is \(resultValue)")

print(multiply(firsNumber: 25, seconNumber: 3))

print("Result is \(multiply(firsNumber: 25, seconNumber: 5))")


func mul(firsNumber: Int, seconNumber: Int) -> Int {
    firsNumber * seconNumber
}
print("Result is \(mul(firsNumber: 20, seconNumber: 4))")


//Argument parameters

//func sayHello(to: String, and: String){
//    print("Hello \(to) and \(and)")
//}
//
//sayHello(to: "Atharv", and: "Vedant")

func sayHello(to person: String, and anotherperson: String){ //person and anotherPerson are external labels/parameters and to and and are internal label
    print("Hello \(person) and \(anotherperson)")
}
sayHello(to: "Atharv", and: "Vedant")


//Argument parameters
//Omitting labels

func add (_ firstNunmber: Int, _ secondNumber: Int) {
    print("Addition = \(firstNunmber + secondNumber)")
}
add(10, 20) //If we write underscore before lables then we don't need to write label while calling the function



func increamentTheNunber(_ value: Int, by number: Int) {
    print("Increament Value = \(value + number)")
}
increamentTheNunber(15, by: 4)


func dispUserInfo(name: String, place: String = "Pune") {
    print("Name = \(name) Place = \(place)")
}
dispUserInfo(name: "Atharv")
dispUserInfo(name: "Vedant", place: "Mumbai")


func sum(_ num1: Int = 0, _ num2: Int = 0, _ num3: Int = 0,) {
    print(num1 + num2 + num3)
}
sum()
//sum(10)
//sum(25,30) //These are incorrect
sum(50, 30, 10)


func doubleValue(_ num1: Int) -> Int {
    num1 * 2
}
print(doubleValue(5))


func findMinMax(_ firstNumber: Int, _ secondNumber: Int) -> (minValue: Int, maxValue: Int) {
    print("First Number = \(firstNumber) and Second Number = \(secondNumber)")
    if firstNumber > secondNumber{
        return (minValue: secondNumber, maxValue: firstNumber)
    } else {
        return (minValue: firstNumber, maxValue: secondNumber)
    }
}

let (min, max) = findMinMax(95, 25)
print("Minimum = \(min) and maximum = \(max)")

var result = findMinMax(70, 30)
print(result.minValue)
print(result.maxValue)



func dateTimeFormat(from date: Date) -> (year: Int, month: Int, day: Int, hour: Int, minute: Int, second: Int) {
    let calendar = Calendar.current
    let components = calendar.dateComponents([.year, .month, .day, .hour, .minute, .second], from: date)
    return (
        components.year ?? 0,
        components.month ?? 0,
        components.day ?? 0,
        components.hour ?? 0,
        components.minute ?? 0,
        components.second ?? 0
    )
}

let date = Date()
print(dateTimeFormat(from: date))


//Swapping Function

func swapvalues(a: inout Int, b: inout Int){
    
}
