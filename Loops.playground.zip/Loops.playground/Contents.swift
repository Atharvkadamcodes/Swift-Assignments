import UIKit

//FOR loop

for index in 1...5 {
    print(index)
}

for _ in 1...5 {
    print("Hello!")
}

let names: [String] = ["Alice", "Bob", "Charlie"]
for name in names {
    print("Hello, \(name)!")
}

for letter in "ABCDEF" {
    print("Letter is: \(letter)")
}
 
for (index, letter) in "ABCDEF".enumerated() {
    print("Index \(index): \(letter)")
}

let vehicles = ["Car": 4, "Motorcycle": 2, "Train": 8, "Plane": 0]
for (vehicleNames, wheelCount) in vehicles {
    print(vehicleNames + " has \(wheelCount) wheels")
}


let animals = ["cat", "dog", "bird", "fish"]
for index in 0..<animals.count {
print("Animal \(index + 1): \(animals[index])")
}

let minutes = 60
let minuteInterval = 5

//for tickMark in stride(from: 0, to: minutes, by: minuteInterval) {
//    print(tickMark) //It wiil no print 60
//}

for tickMark in stride(from: 0, through: minutes, by: minuteInterval) {
    print(tickMark) //It will print 60
}


for var index in 1...10 {
    index += 1
    print(index)
}

for counter in -10...10 {
    print(counter)
    if counter == 0 {
        break
    }
}

//WHILE loop

var number = 0

while number < 10 {
    number += 1
    if number % 2 == 0 {
        continue
    }
}


var count = 0

repeat {  //Its like "DO WHILE LOOP"
    print(count)
    count += 1
} while count < 0

while count < 0 {
    print(count)
    count += 1
}
