import UIKit

class Person { //Class is referrence type and struct is value types
    let name: String
    init(name: String) {
        self.name = name
    }
    
    func sayhello() {
        print("Hello there!")
    }
}

let person = Person(name: "John")
print(person.name)
person.sayhello()


class Vehicle {
    var currentSpeed = 0.0
    
    var description: String {
        "traveling at \(currentSpeed) miles per hour"
    }
    
    func makeNoise() {
        
    }
}
let someValue = Vehicle()
print("V")

class Bicycle: Vehicle {
    var hasBasket = false
}

class Tandem: Bicycle { // Override function is used when same function is used in baseclass as well as subclass
    
}

class Train: Vehicle {
    override func makeNoise() {
        print("Choo Choo!")
    }
}
let train = Train()
train.makeNoise()
print(train.description)
